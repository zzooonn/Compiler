#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <stack>
#include <cctype> 
#include <algorithm>
#include <unordered_set>

using namespace std;

enum TokenType {
    IDENFR, INTCON, STRCON, CHRCON, MAINTK, CONSTTK, INTTK, CHARTK, BREAKTK,
    CONTINUETK, IFTK, ELSETK, FORTK, GETINTTK, GETCHARTK, PRINTFTK, RETURNTK,
    VOIDTK, NOT, AND, OR, MULT, DIV, MOD, LSS, LEQ, GRE, GEQ, EQL, NEQ, ASSIGN,
    PLUS, MINU, SEMICN, COMMA, LPARENT, RPARENT, LBRACK, RBRACK, LBRACE, RBRACE
};

unordered_map<string, TokenType> keywords = {
    {"const", CONSTTK}, {"int", INTTK}, {"char", CHARTK}, {"break", BREAKTK},
    {"continue", CONTINUETK}, {"if", IFTK}, {"else", ELSETK}, {"for", FORTK},
    {"getint", GETINTTK}, {"getchar", GETCHARTK}, {"printf", PRINTFTK},
    {"return", RETURNTK}, {"void", VOIDTK}, {"main", MAINTK}
};

unordered_map<string, TokenType> operators = {
    {"+", PLUS}, {"-", MINU}, {"*", MULT}, {"/", DIV}, {"%", MOD},
    {"<", LSS}, {"<=", LEQ}, {">", GRE}, {">=", GEQ}, {"==", EQL},
    {"!=", NEQ}, {"=", ASSIGN}, {"&&", AND}, {"||", OR}, {"!", NOT},
    {";", SEMICN}, {",", COMMA}, {"(", LPARENT}, {")", RPARENT},
    {"[", LBRACK}, {"]", RBRACK}, {"{", LBRACE}, {"}", RBRACE}
};

struct Token {
    TokenType type;
    string value;
    int lineNumber;
};

struct Error {
    int lineNumber;
    char errorcode;
};

struct Symbol {
    int scopelineNumber;
    string name;
    string type;
    bool isFunction;    // 함수 여부
};

// 함수
void lexicalAnalysis(const string& filename);
void outputToken(const Token& token);
void advanceToken();
void parseExp();
void parseNumber();
void parseCharacter();
void parseLVal();
void parsePrimaryExp();
int parseFuncRParams(vector<string>& passedParamTypes);
void parseCond();
void parseUnaryOp();
void parseUnaryExp();
void parseConstExp();
void parseMulExp();
void parseAddExp();
void parseRelExp();
void parseEqExp();
void parseLAndExp();
void parseLOrExp();
void parseForStmt();
bool parseStmt();
void parseFuncType();
void parseBType();
void parseConstDecl();
void parseConstDef();
string parseFuncFParam(string& paramType);
void parseFuncDef();
int parseFuncFParams(vector<string>& paramTypes);
void parseMainFuncDef();
void parseConstInitVal();
void parseVarDecl();
void parseVarDef();
void parseInitVal();
bool parseBlockItem();
bool parseBlock();
void parseDecl();
void parseCompUnit();

// 전역 변수 선언
vector<Token> tokens;
vector<Error> errors;
size_t tokenIndex = 0;
int lineNumber = 1;
ofstream outputFile;
bool inConditionalContext = false;

vector<Symbol> symbolTable;
stack<int> scopeStack;  // 스코프 번호 스택 
int CurrentScope = 1;
int NextScope = 2;
string currentBaseType;
int scopeCounter = 1;
string funcName;
unordered_map<string, int> functionParams; // 함수 이름과 파라미터 개수를 저장
string currentReturnType; // 현재 리턴 타입 저장 
bool inLoopContext = false;
unordered_map<string, vector<string>> functionParamsTypes; // 함수 이름과 매개변수 타입을 저장
vector<string> passedParamTypes;  // 전달된 매개변수의 타입을 저장하는 벡터


string tokenTypeToString(TokenType type) {
    switch (type) {
    case IDENFR: return "IDENFR";
    case INTCON: return "INTCON";
    case STRCON: return "STRCON";
    case CHRCON: return "CHRCON";
    case MAINTK: return "MAINTK";
    case CONSTTK: return "CONSTTK";
    case INTTK: return "INTTK";
    case CHARTK: return "CHARTK";
    case BREAKTK: return "BREAKTK";
    case CONTINUETK: return "CONTINUETK";
    case IFTK: return "IFTK";
    case ELSETK: return "ELSETK";
    case FORTK: return "FORTK";
    case GETINTTK: return "GETINTTK";
    case GETCHARTK: return "GETCHARTK";
    case PRINTFTK: return "PRINTFTK";
    case RETURNTK: return "RETURNTK";
    case VOIDTK: return "VOIDTK";
    case NOT: return "NOT";
    case AND: return "AND";
    case OR: return "OR";
    case MULT: return "MULT";
    case DIV: return "DIV";
    case MOD: return "MOD";
    case LSS: return "LSS";
    case LEQ: return "LEQ";
    case GRE: return "GRE";
    case GEQ: return "GEQ";
    case EQL: return "EQL";
    case NEQ: return "NEQ";
    case ASSIGN: return "ASSIGN";
    case PLUS: return "PLUS";
    case MINU: return "MINU";
    case SEMICN: return "SEMICN";
    case COMMA: return "COMMA";
    case LPARENT: return "LPARENT";
    case RPARENT: return "RPARENT";
    case LBRACK: return "LBRACK";
    case RBRACK: return "RBRACK";
    case LBRACE: return "LBRACE";
    case RBRACE: return "RBRACE";
    default: return "UNKNOWN";
    }
}

string SymbolType(bool isConst, const string& baseType, bool isArray, bool isFunc) {

    if (isConst) {
        if (isArray) {
            if (baseType == "int") return "ConstIntArray";
            else if (baseType == "char") return "ConstCharArray";
        }
        else {
            if (baseType == "int") return "ConstInt";
            else if (baseType == "char") return "ConstChar";
        }
    }

    else if (isFunc) {
        if (baseType == "void") return "VoidFunc";
        else if (baseType == "int") return "IntFunc";
        else if (baseType == "char") return "CharFunc";
    }

    else {
        if (isArray) {
            if (baseType == "int") return "IntArray";
            else if (baseType == "char") return "CharArray";
        }
        else {
            if (baseType == "int") return "Int";
            else if (baseType == "char") return "Char";
        }
    }
}

// 스코프를 테이블에 추가
void addScope(int scopelineNumber, const string& name, const string& type) {
    symbolTable.push_back({ scopelineNumber, name, type });
}

// 심볼 추가 함수
void addSymbol(const string& name, const string& type, bool isFunction = false) {
    Symbol sym;
    sym.name = name;
    sym.type = type;
    sym.scopelineNumber = CurrentScope;
    sym.isFunction = isFunction;
    symbolTable.push_back(sym);

    cout << "Symbol added: " << sym.name << " | Type: " << sym.type << " | Scope: " << sym.scopelineNumber << " | IsFunction: " << (isFunction ? "Yes" : "No") << endl;
}

void enterScope() {
    scopeCounter++;
    scopeStack.push(CurrentScope);
    CurrentScope = scopeCounter;
}

void exitScope() {
    if (!scopeStack.empty()) {
        CurrentScope = scopeStack.top();
        scopeStack.pop();
    }
}

// 현재 위치의 토큰을 가져옴
Token getCurrentToken() {
    if (tokenIndex < tokens.size()) return tokens[tokenIndex];
    else exit(1);
}

// 이전 토큰을 반환하는 함수
Token getPreviousToken() {
    if (tokenIndex > 0 && tokenIndex - 1 < tokens.size())
        return tokens[tokenIndex - 1];
    else
        return Token{ IDENFR, "", 0 }; // 기본값 반환 (필요에 따라 수정 가능)
}

// 변수 이름 중복 오류 
void parseErrorPrintB(const Token& token) {
    errors.push_back({ token.lineNumber, 'b' });
}

// 현재 스코프에 동일한 심볼이 있는지
bool isSymbolDefinedInCurrentScope(const string& name) {
    for (const auto& sym : symbolTable) {
        if (sym.name == name && sym.scopelineNumber == CurrentScope) {
            return true;
        }
    }
    return false;
}

// 심볼 추가 시 중복 검사 후 추가 또는 오류 처리
void addSymbolWithCheck(const Token& token, const string& type, bool isFunction = false) {
    const string& name = token.value;

    if (isSymbolDefinedInCurrentScope(name)) {
        if (isFunction) {
            parseErrorPrintB(token);
            return;
        }
        else {
            // 변수인 경우 중복 정의 오류 처리
            parseErrorPrintB(token);
            return;
        }
    }
    else {
        // 심볼 테이블에 추가
        addSymbol(name, type, isFunction);
    }
}


// 변수 식별자 없는 경우 
void parseErrorPrintC(const Token& token) {
    errors.push_back({ token.lineNumber, 'c' });
}

// 식별자가 있는지 판단
bool isSymbolDefined(const string& name) {
    for (const auto& sym : symbolTable) {
        if (sym.name == name) {
            return true;
        }
    }
    return false;
}

void parseErrorPrintD(const Token& token) {
    errors.push_back({ token.lineNumber, 'd' });
}

void parseErrorPrintE() {
    Token token = getCurrentToken();
    errors.push_back({ token.lineNumber, 'e' });
}

void parseErrorPrintF(const Token& token) {
    errors.push_back({ token.lineNumber, 'f' });
}

void parseErrorPrintG(const Token& token) {
    errors.push_back({ token.lineNumber, 'g' });
}

// const 
void parseErrorPrintH() {
    Token token = getCurrentToken();
    errors.push_back({ token.lineNumber, 'h' });
}

// 상수 여부 확인 
bool isConstLVal(const string& name) {
    for (const auto& sym : symbolTable) {
        // 현재 스코프에 있는 변수만 확인
        if (sym.name == name && sym.scopelineNumber == CurrentScope) {
            if (sym.type == "ConstInt" || sym.type == "ConstChar" || sym.type == "ConstIntArray" || sym.type == "ConstCharArray") {
                return true;
            }
            return false;  // 상수는 아니지만 동일한 이름을 가진 변수
        }
    }
    return false;
}

// ; 누락 
void parseErrorPrintfI() {
    Token currentToken = getCurrentToken();
    Token previousToken = getPreviousToken(); // 이전 토큰을 가져오는 함수 필요

    if (currentToken.type == SEMICN) {
        outputToken(currentToken);
        advanceToken();
    }
    else {
        // 오류를 이전 토큰의 라인 넘버로 보고
        errors.push_back({ previousToken.lineNumber, 'i' });
    }
}

// ) 누락
void parseErrorPrintfJ() {
    Token token = getCurrentToken();

    if (token.type == RPARENT) {
        outputToken(token);
        advanceToken();
    }

    else {
        errors.push_back({ token.lineNumber, 'j' });
    }
}

// ] 누락
void parseErrorPrintfK() {
    Token token = getCurrentToken();

    if (token.type == RBRACK) {
        outputToken(token);
        advanceToken();
    }

    else {
        errors.push_back({ token.lineNumber, 'k' });
    }
}

void parseErrorPrintL() {
    Token token = getCurrentToken();
    errors.push_back({ token.lineNumber, 'l' });
}

void parseErrorPrintM() {
    Token token = getCurrentToken();
    errors.push_back({ token.lineNumber, 'm' });
}

// 어휘 분석구문
void lexicalAnalysis(const string& filename) {

    ifstream inputFile(filename);
    char currentChar;

    while (inputFile.get(currentChar)) {

        if (isspace(currentChar)) {
            if (currentChar == '\n') {
                lineNumber++;
            }
            continue;
        }

        // 주석 처리 및 나누기 처리
        else if (currentChar == '/') {
            char nextChar = inputFile.peek();

            // 주석인데 /*로 시작할 경우
            if (nextChar == '*') {

                inputFile.get(); // '*' 소비
                bool endofComment = false;

                while (inputFile.get(currentChar)) {
                    if (currentChar == '\n') {
                        lineNumber++;
                    }

                    else if (currentChar == '*') {
                        if (inputFile.peek() == '/') {
                            inputFile.get(); // '/' 소비
                            endofComment = true;
                            break;
                        }
                    }

                    if (inputFile.eof()) break; // 파일 끝에 도달 시 종료
                }
                continue;
            }

            // 주석인데 //로 시작할 경우
            else if (nextChar == '/') {
                inputFile.get(); // 두 번째 '/' 소비

                while (inputFile.get(currentChar)) {
                    if (currentChar == '\n') {
                        lineNumber++; // 줄 번호 증가
                        break;
                    }

                    if (inputFile.eof()) break; // 파일 끝에 도달 시 종료
                }
                continue;
            }

            // 나눗셈인 경우
            else {
                tokens.push_back({ DIV, "/", lineNumber });
            }
        }

        // 식별자 처리
        else if (isalpha(currentChar) || currentChar == '_')
        {
            string ident;   // 식별자 선언 
            ident += currentChar;

            while (inputFile.peek() != EOF && (isalnum(inputFile.peek()) || inputFile.peek() == '_'))
            {
                ident += inputFile.get();
            }

            // 키워드인지 판단
            if (keywords.find(ident) != keywords.end())
            {
                tokens.push_back({ keywords[ident], ident, lineNumber });
            }
            else
            {
                // 식별자 토큰 추가
                tokens.push_back({ IDENFR, ident, lineNumber });
            }
        }

        // 숫자 처리
        else if (isdigit(currentChar)) {
            string number;
            number += currentChar;

            // EOF 체크 추가
            while (isdigit(inputFile.peek())) {
                number += inputFile.get();
            }
            tokens.push_back({ INTCON, number, lineNumber });
        }

        // 문자열 상수 처리
        else if (currentChar == '"') {
            string strConst;
            strConst += currentChar;
            bool closed = false;

            while (inputFile.peek() != EOF) {
                char c = inputFile.get();
                strConst += c;

                if (c == '"') {
                    closed = true;
                    break;
                }

                if (c == '\n') {
                    lineNumber++;
                    break;
                }

                if (inputFile.eof()) break; // 파일 끝에 도달 시 종료
            }

            if (closed) {
                tokens.push_back({ STRCON, strConst, lineNumber });
            }
            else {
                errors.push_back({ lineNumber, 'a' });
            }
        }

        // 문자 상수 처리
        else if (currentChar == '\'') {

            string charConst;
            charConst += currentChar;       // 첫 번째 따옴표 추가
            char c = inputFile.get();
            charConst += c;

            if (c == '\\') // 이스케이프 시퀀스 시작
            {
                char nextChar = inputFile.get();
                charConst += nextChar; // 이스케이프 시퀀스의 두 번째 문자 추가
                c = nextChar; // c를 업데이트하여 다음 검사에서 사용
            }

            if (inputFile.peek() == '\'') {
                charConst += inputFile.get(); // 종료 따옴표 추가
                tokens.push_back({ CHRCON, charConst, lineNumber });
            }
            else {
                // 오류 발생 시 errors 벡터에 추가
                errors.push_back({ lineNumber, 'a' }); // 오류 코드 설정
            }
        }

        // 연산자 및 구분자 처리
        else {
            string op(1, currentChar);
            char nextChar = inputFile.peek();

            if (currentChar == '&') {

                if (nextChar == '&') {
                    op += inputFile.get();
                    tokens.push_back({ AND, op, lineNumber });
                }

                else {
                    errors.push_back({ lineNumber, 'a' });
                    tokens.push_back({ AND, "&&", lineNumber });
                    continue;
                }
            }

            else if (currentChar == '|') {

                if (nextChar == '|') {
                    op += inputFile.get();
                    tokens.push_back({ OR, op, lineNumber });
                }

                else {
                    errors.push_back({ lineNumber, 'a' });
                    tokens.push_back({ AND, "&&", lineNumber });
                    continue;
                }
            }

            else if ((currentChar == '!' || currentChar == '=' || currentChar == '<' || currentChar == '>') && nextChar == '=') {
                op += inputFile.get();
                tokens.push_back({ operators[op], op, lineNumber });
            }

            else if (operators.find(op) != operators.end()) {
                tokens.push_back({ operators[op], op, lineNumber });
            }
        }

        if (inputFile.eof()) break; // 파일 끝에 도달 시 종료
    }

    inputFile.close();
}

// 출력
void outputToken(const Token& token) {
    outputFile << tokenTypeToString(token.type) << " " << token.value << endl;
}

// %d, %c인 경우만 개수를 세는 함수
int countFormatSpecifiers(const string& formatString) {
    int count = 0;
    for (size_t i = 0; i < formatString.length(); ++i) {
        if (formatString[i] == '%' && i + 1 < formatString.length()) {
            // %d 또는 %c인 경우에만 카운트 증가
            if (formatString[i + 1] == 'd' || formatString[i + 1] == 'c') {
                count++;
                i++; // 포맷 specifier 뒤의 문자를 건너뜁니다.
            }
        }
    }
    return count;
}

// 토큰 인덱스 증가
void advanceToken() {
    if (tokenIndex < tokens.size())
    {
        tokenIndex++;
    }
}

// Number → IntConst 
void parseNumber() {
    Token token = getCurrentToken();

    if (token.type == INTCON) {
        if (token.value.length() > 1 && token.value[0] == '0') {
            return;
        }
        else {
            outputToken(token);
            advanceToken();
        }
    }
}

// Character → CharConst
void parseCharacter() {
    Token token = getCurrentToken();

    if (token.type == CHRCON) {
        char character = token.value[1];

        if ((character >= 32 && character <= 126) ||
            character == '\a' || character == '\b' || character == '\t' ||
            character == '\n' || character == '\v' || character == '\f' ||
            character == '\r' || character == '\\' || character == '\'' ||
            character == '\"')
        {
            outputToken(token);
            advanceToken();
        }
    }
    outputFile << "<Character>" << endl;
}

// LVal → Ident ['[' Exp ']'] // k
void parseLVal() {

    Token token = getCurrentToken();

    if (token.type == IDENFR) {

        if (!isSymbolDefined(token.value)) {
            parseErrorPrintC(token);
        }
        outputToken(token);
        advanceToken();
        token = getCurrentToken();
    }

    if (token.type == LBRACK) {
        outputToken(token);
        advanceToken();
        token = getCurrentToken();

        parseExp();
        token = getCurrentToken();

        if (token.type == RBRACK) {
            outputToken(token);
            advanceToken();
            token = getCurrentToken();
        }

        else parseErrorPrintfK();
    }

    outputFile << "<LVal>" << endl;
}

// LOrExp → LAndExp { '||' LAndExp }
void parseLOrExp() {

    parseLAndExp();
    outputFile << "<LOrExp>" << endl;

    if (getCurrentToken().type == OR) {
        outputToken(getCurrentToken());
        advanceToken();
        parseLOrExp();
    }

}

// LAndExp → EqExp { '&&' EqExp }
void parseLAndExp() {

    parseEqExp();
    outputFile << "<LAndExp>" << endl;

    if (getCurrentToken().type == AND) {
        outputToken(getCurrentToken());
        advanceToken();
        parseLAndExp();
    }

}

// UnaryOp → '+' | '?' | '!' 注：'!'?出?在?件表?式中 
void parseUnaryOp() {
    Token token = getCurrentToken();

    if (token.type == PLUS || token.type == MINU || token.type == NOT)
    {
        outputToken(token);
        advanceToken();
    }
    outputFile << "<UnaryOp>" << endl;
}

// UnaryExp → PrimaryExp | Ident '(' [FuncRParams] ')' | UnaryOp UnaryExp // j
void parseUnaryExp() {
    Token token = getCurrentToken();

    // UnaryOp UnaryExp 
    if (token.type == PLUS || token.type == MINU || token.type == NOT) {
        parseUnaryOp();
        parseUnaryExp();
    }

    // Ident '(' [FuncRParams] ')'    
    else if (getCurrentToken().type == IDENFR) {

        // 함수 호출인지 확인
        if (tokenIndex + 1 < tokens.size() && tokens[tokenIndex + 1].type == LPARENT) {

            if (!isSymbolDefined(token.value)) {
                parseErrorPrintC(token);
            }

            funcName = token.value;

            outputToken(getCurrentToken());
            advanceToken();
            outputToken(getCurrentToken());
            advanceToken();

            vector<string> passedParamTypes;
            int paramCount = 0;
            // [FuncRParams] 처리 
            if (getCurrentToken().type != RPARENT) {
                paramCount = parseFuncRParams(passedParamTypes);
            }

            // ')' 처리
            if (getCurrentToken().type == RPARENT) {
                outputToken(getCurrentToken());
                advanceToken();
            }
            else {
                parseErrorPrintfJ();
            }

            // 함수 정의와 매개변수 타입 비교
            if (functionParamsTypes.find(funcName) != functionParamsTypes.end()) {
                const vector<string>& expectedParamTypes = functionParamsTypes[funcName];

                // 매개변수 개수 비교
                if (paramCount != expectedParamTypes.size()) {
                    parseErrorPrintD(token); // 매개변수 개수 불일치
                }
                else {
                    for (size_t i = 0; i < paramCount; ++i) {
                        if (passedParamTypes[i] != expectedParamTypes[i]) {
                            parseErrorPrintE(); // 매개변수 타입 불일치 에러
                            break;
                        }
                    }
                }
            }
        }

        else {
            parsePrimaryExp();
        }
    }

    else {
        parsePrimaryExp();
    }

    outputFile << "<UnaryExp>" << endl;
}

// Exp → AddExp 
void parseExp() {
    parseAddExp();

    outputFile << "<Exp>" << endl;
}

// AddExp → MulExp | AddExp ('+' | '?') MulExp 
void parseAddExp() {

    parseMulExp();
    outputFile << "<AddExp>" << endl;

    if (getCurrentToken().type == PLUS || getCurrentToken().type == MINU) {
        outputToken(getCurrentToken());
        advanceToken();
        parseAddExp();
    }
}

// PrimaryExp → '(' Exp ')' | LVal | Number | Character // j
void parsePrimaryExp() {

    // '(' Exp ')'
    if (getCurrentToken().type == LPARENT) {
        outputToken(getCurrentToken());  // '(' 출력
        advanceToken();

        parseExp();  // Exp 파싱

        // ')' 확인
        if (getCurrentToken().type == RPARENT) {
            outputToken(getCurrentToken());
            advanceToken();
        }
        else {
            parseErrorPrintfJ();
        }
    }

    // LVal 처리
    else if (getCurrentToken().type == IDENFR) {
        parseLVal();
    }

    // Number 처리
    else if (getCurrentToken().type == INTCON) {
        outputToken(getCurrentToken());
        advanceToken();
        outputFile << "<Number>" << endl;
    }

    // Character 처리
    else if (getCurrentToken().type == CHRCON) {
        outputToken(getCurrentToken());
        advanceToken();
        outputFile << "<Character>" << endl;
    }

    outputFile << "<PrimaryExp>" << endl;
}

// MulExp →  MulExp → UnaryExp | MulExp ('*' | '/' | '%') UnaryExp
void parseMulExp() {

    parseUnaryExp();
    outputFile << "<MulExp>" << endl;

    if (getCurrentToken().type == MULT || getCurrentToken().type == DIV || getCurrentToken().type == MOD) {
        outputToken(getCurrentToken());
        advanceToken();

        parseMulExp();
    }
}

// RelExp → AddExp | RelExp ('<' | '>' | '<=' | '>=') AddExp 
void parseRelExp() {

    parseAddExp();
    outputFile << "<RelExp>" << endl;

    if (getCurrentToken().type == LSS || getCurrentToken().type == LEQ || getCurrentToken().type == GRE || getCurrentToken().type == GEQ) {
        outputToken(getCurrentToken());
        advanceToken();
        parseRelExp();
    }

}

// EqExp → RelExp | EqExp ('==' | '!=') RelExp 
void parseEqExp() {

    parseRelExp();
    outputFile << "<EqExp>" << endl;

    if (getCurrentToken().type == EQL || getCurrentToken().type == NEQ) {
        outputToken(getCurrentToken());
        advanceToken();
        parseEqExp();
    }
}

// ForStmt → LVal '=' Exp 
void parseForStmt() {

    parseLVal();

    if (getCurrentToken().type == ASSIGN)
    {
        outputToken(getCurrentToken());
        advanceToken();
    }
    else {
        advanceToken();
    }

    parseExp();

    outputFile << "<ForStmt>" << endl;
}

// BType → 'int' | 'char' 
void parseBType() {
    Token token = getCurrentToken();

    if (token.type == INTTK || token.type == CHARTK)
    {
        if (token.type == INTTK) {
            currentBaseType = "int";
        }
        else {
            currentBaseType = "char";
        }

        outputToken(token);
        advanceToken();
    }
}

// ConstDecl → 'const' BType ConstDef { ',' ConstDef } ';'  // i
void parseConstDecl() {

    if (getCurrentToken().type == CONSTTK) {
        outputToken(getCurrentToken());
        advanceToken();
    }

    parseBType();
    parseConstDef();

    while (getCurrentToken().type == COMMA) {
        outputToken(getCurrentToken());
        advanceToken();
        parseConstDef();
    }

    if (getCurrentToken().type == SEMICN) {
        outputToken(getCurrentToken());
        advanceToken();
    }
    else {
        parseErrorPrintfI();
    }

    outputFile << "<ConstDecl>" << endl;
}

// Decl → ConstDecl | VarDecl 
void parseDecl() {

    Token token = getCurrentToken();

    if (token.type == CONSTTK) {
        parseConstDecl();
    }
    else if (token.type == INTTK || token.type == CHARTK) {
        parseVarDecl();
    }
}

// Block → '{' { BlockItem } '}'
bool parseBlock() {

    Token token = getCurrentToken();
    bool hasReturn = false;

    // '{'
    if (token.type == LBRACE) {
        outputToken(token);
        advanceToken();
        enterScope();
    }

    // { BlockItem }
    while (getCurrentToken().type != RBRACE) {
        bool stmthasReturn = parseBlockItem();

        if (!hasReturn) {
            hasReturn = stmthasReturn;
        }
    }

    // '}'
    token = getCurrentToken();
    if (getCurrentToken().type == RBRACE) {
        outputToken(getCurrentToken());
        advanceToken();
        exitScope();
    }

    outputFile << "<Block>" << endl;
    return hasReturn;
}

// BlockItem → Decl | Stmt
bool parseBlockItem() {
    Token token = getCurrentToken();

    if (token.type == CONSTTK || token.type == INTTK || token.type == CHARTK) {
        parseDecl();
        return false;
    }

    else {
        return parseStmt();
    }
}

// FuncFParam → BType Ident ['[' ']'] // k
string parseFuncFParam(string& paramType) {

    parseBType();
    Token token = getCurrentToken();
    string paramName;
    paramType = currentBaseType; // 매개변수의 기본 타입 저장

    if (token.type == IDENFR) {
        paramName = token.value;
        string symbolType = SymbolType(false, currentBaseType, false, false); // 변수 이름 변경

        addScope(CurrentScope, paramName, symbolType);
        outputToken(token);
        advanceToken();
    }

    bool isArray = false;
    if (getCurrentToken().type == LBRACK) {
        outputToken(getCurrentToken());
        advanceToken();

        token = getCurrentToken();
        if (token.type == RBRACK) {
            outputToken(token);
            advanceToken();
            isArray = true;

            symbolTable.back().type = SymbolType(false, currentBaseType, true, false);
            paramType += "Array";
        }
        else {
            parseErrorPrintfK();
        }
    }

    outputFile << "<FuncFParam>" << endl;

    return paramName;
}

// Stmt
bool parseStmt() {
    Token token = getCurrentToken();

    bool isReturn = false;

    // 'break' ';' // i
    if (token.type == BREAKTK) {

        if (!inLoopContext) {
            parseErrorPrintM();
        }

        outputToken(token);
        advanceToken();
        token = getCurrentToken();

        if (token.type == SEMICN) {
            outputToken(token);
            advanceToken();
        }
        else {
            parseErrorPrintfI();
        }
    }

    // 'continue' ';' // i
    else if (token.type == CONTINUETK) {

        if (!inLoopContext) {
            parseErrorPrintM();
        }

        outputToken(token);
        advanceToken();

        if (getCurrentToken().type == SEMICN) {
            outputToken(getCurrentToken());
            advanceToken();
        }
        else {
            parseErrorPrintfI();
        }
    }

    // 'return' [Exp] ';'// i
    else if (token.type == RETURNTK) {
        outputToken(token);
        advanceToken();

        Token ReturnToken = token;

        if (getCurrentToken().type != SEMICN) {

            if (currentReturnType == "void") {
                parseErrorPrintF(ReturnToken);
            }
            parseExp();
        }

        if (getCurrentToken().type == SEMICN) {
            outputToken(getCurrentToken());
            advanceToken();
        }

        else {
            parseErrorPrintfI();
        }

        isReturn = true;
    }

    // 'if' '(' Cond ')' Stmt [ 'else' Stmt ] // j
    else if (token.type == IFTK) {
        outputToken(token);
        advanceToken();

        if (getCurrentToken().type == LPARENT) {
            outputToken(getCurrentToken());
            advanceToken();
        }

        parseCond();  // Cond 처리

        if (getCurrentToken().type == RPARENT) {
            outputToken(getCurrentToken());
            advanceToken();
        }
        else {
            parseErrorPrintfJ();
        }

        parseStmt();  // 본문 Stmt 처리

        if (getCurrentToken().type == ELSETK) {
            outputToken(getCurrentToken());
            advanceToken();
            parseStmt();  // else 구문 처리
        }
    }

    // 'for' '(' [ForStmt] ';' [Cond] ';' [ForStmt] ')' Stmt
    else if (token.type == FORTK) {
        outputToken(token);
        advanceToken();

        if (getCurrentToken().type == LPARENT) {
            outputToken(getCurrentToken());
            advanceToken();
        }

        if (getCurrentToken().type != SEMICN) {
            parseForStmt();
        }

        if (getCurrentToken().type == SEMICN) {
            outputToken(getCurrentToken());
            advanceToken();
        }
        else {
            parseErrorPrintfI();
        }

        if (getCurrentToken().type != SEMICN) {
            parseCond();
        }

        if (getCurrentToken().type == SEMICN) {
            outputToken(getCurrentToken());
            advanceToken();
        }
        else {
            parseErrorPrintfI();
        }

        if (getCurrentToken().type != RPARENT) {
            parseForStmt();
        }

        if (getCurrentToken().type == RPARENT) {
            outputToken(getCurrentToken());
            advanceToken();
        }
        else {
            parseErrorPrintfJ();
        }

        bool previousLoopContext = inLoopContext;
        inLoopContext = true;

        parseStmt();

        inLoopContext = previousLoopContext;
    }

    // Stmt → ‘printf’ ‘(’ FormatString {, Exp}’)’ ‘;’
    else if (token.type == PRINTFTK) {
        outputToken(token);
        advanceToken();

        if (getCurrentToken().type == LPARENT) {
            outputToken(getCurrentToken());
            advanceToken();
        }

        int formatSpecifierCount = 0;
        int expressionCount = 0;

        // 포맷 문자열 확인
        if (getCurrentToken().type == STRCON) {
            string formatString = getCurrentToken().value;
            formatSpecifierCount = countFormatSpecifiers(formatString); // 포맷 specifier 개수 세기
            outputToken(getCurrentToken());
            advanceToken();
        }

        // 표현식들 확인
        while (getCurrentToken().type == COMMA) {
            outputToken(getCurrentToken());
            advanceToken();
            parseExp();
            expressionCount++;
        }

        // 포맷 specifier의 개수와 표현식의 개수가 일치하지 않는지 확인
        if (expressionCount != formatSpecifierCount) {
            Token printfToken = getPreviousToken();  // printf 토큰의 위치
            errors.push_back({ printfToken.lineNumber, 'l' });  // l 오류 기록
        }

        if (getCurrentToken().type == RPARENT) {
            outputToken(getCurrentToken());
            advanceToken();
        }
        else {
            parseErrorPrintfJ();
        }

        if (getCurrentToken().type == SEMICN) {
            outputToken(getCurrentToken());
            advanceToken();
        }
        else {
            parseErrorPrintfI();
        }
    }


    // Block 처리
    else if (token.type == LBRACE) {
        parseBlock();
    }

    // 단독 세미콜론 처리 (빈 문장)
    else if (token.type == SEMICN) {
        outputToken(token);
        advanceToken();
    }

    // LVal '=' Exp ';' 또는 LVal '=' 'getint' '(' ')' ';' 또는 'getchar' '(' ')' ';'
    else {
        int index = 0;
        bool isLVal = false;

        // LVal 여부 판단 (다음 토큰이 '='인지 확인)
        if (tokenIndex + 1 < tokens.size()) {

            Token nextToken = tokens[tokenIndex + 1];

            while (true) {
                if (nextToken.type == ASSIGN) {
                    isLVal = true;
                    break;
                }

                if (nextToken.type == SEMICN || tokenIndex + index >= tokens.size()) {
                    break;
                }
                index++;
                nextToken = tokens[tokenIndex + index];
            }
        }

        // LVal인 경우 처리
        if (isLVal) {
            string lvalName = getCurrentToken().value;
            parseLVal(); // LVal 처리

            // '=' 출력 및 다음 토큰으로 이동
            outputToken(getCurrentToken());
            advanceToken();
            Token token = getCurrentToken();

            if (isConstLVal(lvalName)) {
                parseErrorPrintH();
            }

            // 'getint' 또는 'getchar' 처리
            if (token.type == GETINTTK || token.type == GETCHARTK) {
                outputToken(token);
                advanceToken();

                // '(' 처리
                if (getCurrentToken().type == LPARENT) {
                    outputToken(getCurrentToken());
                    advanceToken();
                }

                // ')' 처리
                if (getCurrentToken().type == RPARENT) {
                    outputToken(getCurrentToken());
                    advanceToken();
                }
                else {
                    parseErrorPrintfJ();
                }

                // ';' 처리
                if (getCurrentToken().type == SEMICN) {
                    outputToken(getCurrentToken());
                    advanceToken();
                }
                else {
                    errors.push_back({ token.lineNumber, 'i' });
                }
            }

            // LVal '=' Exp ';' 처리
            else {
                parseExp();

                // ';' 처리
                if (getCurrentToken().type == SEMICN) {
                    outputToken(getCurrentToken());
                    advanceToken();
                }

                else {
                    parseErrorPrintfI();
                }
            }
        }

        // [Exp] ';' 처리
        else {
            if (getCurrentToken().type != SEMICN) {
                parseExp();
            }

            // ';' 처리
            if (getCurrentToken().type == SEMICN) {
                outputToken(getCurrentToken());
                advanceToken();
            }
            else {
                parseErrorPrintfI();
            }
        }
    }
    outputFile << "<Stmt>" << endl;

    return isReturn;
}

// FuncRParams → Exp { ',' Exp } 
int parseFuncRParams(vector<string>& passedParamTypes) {

    int paramCount = 0;
    passedParamTypes.push_back(currentBaseType); // 함수 매개변수 저장
    parseExp();

    paramCount++;

    while (getCurrentToken().type == COMMA) {
        outputToken(getCurrentToken()); // ',' 출력
        advanceToken();
        parseExp();

        passedParamTypes.push_back(currentBaseType); // 함수 매개변수 저장
        paramCount++;
    }

    outputFile << "<FuncRParams>" << endl;

    return paramCount;
}

// FuncType → 'void' | 'int' | 'char'
void parseFuncType() {
    Token token = getCurrentToken();

    if (token.type == VOIDTK) {
        currentBaseType = "void";
    }
    else if (token.type == INTTK) {
        currentBaseType = "int";
    }
    else {
        currentBaseType = "char";
    }

    outputToken(token);
    advanceToken();
    token = getCurrentToken();

    outputFile << "<FuncType>" << endl;
}

// FuncFParams → FuncFParam { ',' FuncFParam }
int parseFuncFParams(vector<string>& paramTypes) {

    enterScope();

    unordered_set<string> paramNames;
    int paramCount = 0;
    string paramType; // paramType 변수 선언 추가

    string paramName = parseFuncFParam(paramType);
    paramTypes.push_back(paramType);
    Token token = getCurrentToken();
    paramCount++;

    // 중복된 이름있는지 체크
    if (paramNames.find(paramName) != paramNames.end()) {
        parseErrorPrintB(token);
    }
    else {
        paramNames.insert(paramName);
    }

    while (token.type == COMMA) {
        outputToken(token);
        advanceToken();

        paramName = parseFuncFParam(paramType);
        paramTypes.push_back(paramType);
        token = getCurrentToken();
        paramCount++;

        if (paramNames.find(paramName) != paramNames.end()) {
            parseErrorPrintB(token);
        }
        else {
            paramNames.insert(paramName);
        }
    }

    functionParams[funcName] = paramCount;

    scopeCounter--;
    CurrentScope = scopeCounter;

    exitScope();

    outputFile << "<FuncFParams>" << endl;

    return paramCount;
}

// FuncDef → FuncType Ident '(' [FuncFParams] ')' Block // j
void parseFuncDef() {
    parseFuncType();
    currentReturnType = currentBaseType; // 함수 반환 타입 확인

    Token token = getCurrentToken();

    // Ident (함수 이름)
    if (token.type == IDENFR) {
        string newFuncName = token.value;

        // 함수가 이미 정의되어 있는지 확인
        bool isDuplicate = false;
        if (functionParams.find(newFuncName) != functionParams.end()) {
            isDuplicate = true;
            funcName = newFuncName;
            // 기존 paramCount를 유지

            // 함수 재정의는 허용하지 않으므로 새로운 정의를 무시하고 오류를 기록
            errors.push_back({ token.lineNumber, 'b' }); // 'b' 오류 코드 사용

            // 함수 재정의의 나머지 부분을 파싱하여 토큰을 건너뜁니다.
            outputToken(token);
            advanceToken();

            // '(' 처리
            token = getCurrentToken();
            if (token.type == LPARENT) {
                outputToken(token);
                advanceToken();
            }

            // [FuncFParams] 무시
            while (getCurrentToken().type != RPARENT && getCurrentToken().type != EOF) {
                advanceToken();
            }

            // ')' 처리
            token = getCurrentToken();
            if (token.type == RPARENT) {
                outputToken(token);
                advanceToken();
            }
            else {
                parseErrorPrintfJ();
            }

            // Block 파싱 무시
            parseBlock();

            outputFile << "<FuncDef>" << endl;

            return; // 함수 재정의는 무시
        }
        else {
            // 새로운 함수인 경우, 심볼 테이블에 추가
            funcName = newFuncName;
            addSymbolWithCheck(token, SymbolType(false, currentBaseType, false, true), true); // isFunction=true

            outputToken(token);
            advanceToken();
        }
    }
    vector<string> paramTypes;

    // '(' 처리
    token = getCurrentToken();
    if (token.type == LPARENT) {
        outputToken(token);
        advanceToken();

        // [FuncFParams]

        if (token.type != RPARENT) {
            parseFuncFParams(paramTypes);
        }

        // ')' 처리
        token = getCurrentToken();
        if (token.type == RPARENT) {
            outputToken(token);
            advanceToken();
        }
        else {
            parseErrorPrintfJ();
        }
    }

    // 함수 매개변수 개수를 업데이트
    if (functionParams.find(funcName) == functionParams.end()) {
        // 파싱된 매개변수 개수 및 타입을 맵에 저장
        functionParams[funcName] = paramTypes.size();
        functionParamsTypes[funcName] = paramTypes;
    }
    // 중복된 함수인 경우 paramCount를 유지하므로 업데이트하지 않음

    cout << "Function: " << funcName << ", ParamCount: " << functionParams[funcName] << endl;

    bool hasReturn = parseBlock();

    // 함수 반환 타입이 void가 아니고, 반환문이 없을 경우 에러 g 발생
    if (currentReturnType != "void" && !hasReturn) {
        Token lastToken = getPreviousToken();
        parseErrorPrintG(lastToken);
    }

    outputFile << "<FuncDef>" << endl;
}

// Cond → LOrExp 
void parseCond() {
    parseLOrExp();
    outputFile << "<Cond>" << endl;
}

// ConstDef → Ident [ '[' ConstExp ']' ] '=' ConstInitVal // k
void parseConstDef() {

    Token token = getCurrentToken();
    string constName;

    // Ident 처리
    if (token.type == IDENFR) {
        constName = token.value;
        outputToken(token);
        advanceToken();
    }

    bool isArray = false;
    // '[' ConstExp ']' 처리 
    if (getCurrentToken().type == LBRACK) {
        outputToken(getCurrentToken());
        advanceToken();

        parseConstExp();

        if (getCurrentToken().type == RBRACK) {
            outputToken(getCurrentToken());
            advanceToken();
            isArray = true;
        }

        else parseErrorPrintfK();
    }

    // '=' 처리
    if (getCurrentToken().type == ASSIGN) {
        outputToken(getCurrentToken());
        advanceToken();
    }

    token = getCurrentToken();
    parseConstInitVal();


    string typeName = SymbolType(true, currentBaseType, isArray, false);

    Token identToken = { IDENFR, constName, token.lineNumber };
    addSymbolWithCheck(identToken, typeName);

    //addScope(CurrentScope, constName, typeName);

    outputFile << "<ConstDef>" << endl;
}

// ConstExp → AddExp  비고: 사용하는 Ident는 상수
void parseConstExp() {
    parseAddExp();
    outputFile << "<ConstExp>" << endl;
}

// ConstInitVal → ConstExp | '{' [ ConstExp { ',' ConstExp } ] '}' | StringConst
void parseConstInitVal() {

    // '{' [ ConstExp { ',' ConstExp } ] '}'
    if (getCurrentToken().type == LBRACE) {
        outputToken(getCurrentToken());
        advanceToken();

        if (getCurrentToken().type != RBRACE) {
            parseConstExp();

            while (getCurrentToken().type == COMMA) {
                outputToken(getCurrentToken());
                advanceToken();

                parseConstExp();
            }

            // '}' 확인 
            if (getCurrentToken().type == RBRACE) {
                outputToken(getCurrentToken());
                advanceToken();
            }
        }
        else if (getCurrentToken().type == RBRACE) {
            outputToken(getCurrentToken());
            advanceToken();
        }
    }

    // StringConst 처리
    else if (getCurrentToken().type == STRCON) {
        outputToken(getCurrentToken());
        advanceToken();
    }

    // ConstExp 처리
    else {
        parseConstExp();
    }

    outputFile << "<ConstInitVal>" << endl;
}

// VarDecl → BType VarDef { ',' VarDef } ';' // i
void parseVarDecl() {

    parseBType();
    parseVarDef();

    Token token = getCurrentToken();

    // 여러 변수 정의가 있는 경우 (','로 구분되는 경우)
    while (token.type == COMMA) {
        outputToken(token);
        advanceToken();
        token = getCurrentToken();

        parseVarDef();
        token = getCurrentToken();
    }

    token = getCurrentToken();

    // 세미콜론 ';' 확인
    if (token.type == SEMICN) {
        outputToken(token);
        advanceToken();
    }
    else {
        parseErrorPrintfI();
    }

    outputFile << "<VarDecl>" << endl;
}

// VarDef → Ident [ '[' ConstExp ']' ] | Ident [ '[' ConstExp ']' ] '=' InitVal // k
void parseVarDef() {

    Token token = getCurrentToken();
    string varName;

    // Ident (변수 이름) 확인
    if (token.type == IDENFR) {
        varName = token.value;
        outputToken(token);
        advanceToken();
    }

    bool isArray = false;
    // 배열 구문 처리: '[' ConstExp ']'
    if (getCurrentToken().type == LBRACK) {
        outputToken(getCurrentToken());
        advanceToken();
        parseConstExp();

        if (getCurrentToken().type == RBRACK) {
            outputToken(getCurrentToken());
            advanceToken();
            isArray = true;
        }
        else {
            parseErrorPrintfK();
        }
    }

    // 초기화 구문 처리: '=' InitVal
    if (getCurrentToken().type == ASSIGN) {
        outputToken(getCurrentToken());
        advanceToken();
        parseInitVal();
    }

    string typeName = SymbolType(false, currentBaseType, isArray, false);

    // 중복 검사 후 심볼 추가
    Token identToken = { IDENFR, varName, token.lineNumber };
    addSymbolWithCheck(identToken, typeName);

    outputFile << "<VarDef>" << endl;
}

// InitVal → Exp | '{' [ Exp { ',' Exp } ] '}' | StringConst
void parseInitVal() {

    Token token = getCurrentToken();

    // StringConst
    if (getCurrentToken().type == STRCON) {
        outputToken(getCurrentToken());
        advanceToken();
    }

    // '{' [ Exp { ',' Exp } ] '}'
    else if (getCurrentToken().type == LBRACE) {
        outputToken(getCurrentToken());
        advanceToken();

        // [ Exp { ',' Exp } ]
        if (getCurrentToken().type != RBRACE) {

            // 첫 번째 Exp
            parseExp();

            // { ',' Exp }
            while (getCurrentToken().type == COMMA) {
                outputToken(getCurrentToken());
                advanceToken();

                parseExp();
            }
        }

        // '}'
        if (getCurrentToken().type == RBRACE) {
            outputToken(getCurrentToken());
            advanceToken();
        }
    }

    // Exp
    else {
        parseExp();
    }

    outputFile << "<InitVal>" << endl;
}

// MainFuncDef → 'int' 'main' '(' ')' Block // k
void parseMainFuncDef() {
    Token token = getCurrentToken();

    // int 확인
    if (token.type == INTTK) {
        outputToken(token);
        advanceToken();
        currentReturnType = "int";
    }

    // main 확인
    token = getCurrentToken();
    if (token.type == MAINTK) {
        outputToken(token);
        advanceToken();
    }
    else {
        advanceToken();
    }

    // ( 확인
    token = getCurrentToken();
    if (token.type == LPARENT) {
        outputToken(token);
        advanceToken();
    }

    // ) 확인
    token = getCurrentToken();
    if (token.type == RPARENT) {
        outputToken(token);
        advanceToken();
    }
    else {
        parseErrorPrintfJ();
    }

    bool hasReturn = parseBlock();
    if (!hasReturn) {
        Token lastToken = getPreviousToken();  // 함수 정의의 마지막 토큰
        parseErrorPrintG(lastToken);
    }

    exitScope();

    outputFile << "<MainFuncDef>" << endl;
}

// CompUnit → {Decl} {FuncDef} MainFuncDef
void parseCompUnit()
{
    Token token = getCurrentToken();

    // {Decl}
    while (true)
    {
        token = getCurrentToken();
        if (token.type == CONSTTK) {
            parseConstDecl();
        }

        else if (token.type == INTTK || token.type == CHARTK) {
            if (tokenIndex + 1 < tokens.size())
            {
                Token nextToken = tokens[tokenIndex + 1];
                if (nextToken.type == IDENFR)
                {
                    if (tokenIndex + 2 < tokens.size() && tokens[tokenIndex + 2].type == LPARENT)
                    {
                        break; // 함수 정의로 간주
                    }
                    else
                    {
                        parseVarDecl();
                    }
                }
                else if (nextToken.type == MAINTK)
                {
                    break; // 메인 함수로 간주
                }
                else
                {
                    parseVarDecl();
                }
            }
            else
            {
                parseVarDecl();
            }
        }
        else {
            break;
        }
    }

    // {FuncDef}
    while (true)
    {
        token = getCurrentToken();
        if (token.type == VOIDTK || token.type == INTTK || token.type == CHARTK)
        {
            if (tokenIndex + 1 < tokens.size())
            {
                Token nextToken = tokens[tokenIndex + 1];
                if (nextToken.type == IDENFR)
                {
                    if (tokenIndex + 2 < tokens.size() && tokens[tokenIndex + 2].type == LPARENT)
                    {
                        parseFuncDef(); // 함수 정의 파싱
                        continue;
                    }
                    else
                    {
                        break;
                    }
                }
                else if (nextToken.type == MAINTK)
                {
                    break; // 메인 함수로 간주
                }
                else
                {
                    break;
                }
            }
            else
            {
                break;
            }
        }
        else
        {
            break;
        }
    }

    // MainFuncDef
    parseMainFuncDef();

    outputFile << "<CompUnit>" << endl;
}

int main()
{
    // 어휘 분석 수행
    lexicalAnalysis("testfile.txt");

    /*
    // 어휘 분석
    outputFile.open("lexer.txt");
    for (const auto& token : tokens)
    {
        outputToken(token);
    }
    outputFile.close();

    // 구문 분석
    outputFile.open("parser.txt");
    parseCompUnit();
    outputFile.close();
    */

    parseCompUnit();

    // ??分析: symbolTable을 scopelineNumber 기준으로 오름차순 정렬
    stable_sort(symbolTable.begin(), symbolTable.end(), [](const Symbol& a, const Symbol& b) -> bool {
        return a.scopelineNumber < b.scopelineNumber;
        });

    // 정렬된 symbolTable을 symbol.txt에 출력
    outputFile.open("symbol.txt");
    for (const auto& sym : symbolTable) {
        outputFile << sym.scopelineNumber << " " << sym.name << " " << sym.type << endl;
    }
    outputFile.close();

    // 오류 처리
    if (!errors.empty())
    {
        // lineNumber 기준으로 정렬
        sort(errors.begin(), errors.end(), [](const auto& a, const auto& b) {
            return a.lineNumber < b.lineNumber; // lineNumber가 작은 순서대로 정렬
            });

        ofstream errorFile("error.txt");
        for (const auto& error : errors)
        {
            errorFile << error.lineNumber << " " << error.errorcode << endl;
        }
        errorFile.close();
    }

    return 0;
}
