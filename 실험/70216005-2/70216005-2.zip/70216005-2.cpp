#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <stack>
#include <cctype> 

using namespace std;

enum TokenType {
    IDENFR, INTCON, STRCON, CHRCON, MAINTK, CONSTTK, INTTK, CHARTK, BREAKTK,
    CONTINUETK, IFTK, ELSETK, FORTK, GETINTTK, GETCHARTK, PRINTFTK, RETURNTK,
    VOIDTK, NOT, AND, OR, MULT, DIV, MOD, LSS, LEQ, GRE, GEQ, EQL, NEQ, ASSIGN,
    PLUS, MINU, SEMICN, COMMA, LPARENT, RPARENT, LBRACK, RBRACK, LBRACE, RBRACE
};

unordered_map<string, TokenType> keywords = {
    {"const", CONSTTK}, {"int", INTTK}, {"char", CHARTK}, {"break", BREAKTK},
    {"continue", CONTINUETK}, {"if", IFTK}, {"else", ELSETK}, {"for", FORTK},
    {"getint", GETINTTK}, {"getchar", GETCHARTK}, {"printf", PRINTFTK},
    {"return", RETURNTK}, {"void", VOIDTK}, {"main", MAINTK}
};

unordered_map<string, TokenType> operators = {
    {"+", PLUS}, {"-", MINU}, {"*", MULT}, {"/", DIV}, {"%", MOD},
    {"<", LSS}, {"<=", LEQ}, {">", GRE}, {">=", GEQ}, {"==", EQL},
    {"!=", NEQ}, {"=", ASSIGN}, {"&&", AND}, {"||", OR}, {"!", NOT},
    {";", SEMICN}, {",", COMMA}, {"(", LPARENT}, {")", RPARENT},
    {"[", LBRACK}, {"]", RBRACK}, {"{", LBRACE}, {"}", RBRACE}
};

struct Token {
    TokenType type;
    string value;
    int lineNumber;
};

struct Error {
    int lineNumber;
    char errorcode;
};

vector<Token> tokens;
vector<Error> errors;

/*
unordered_map<string, TokenType> currentScopeSymbols;     // ���� �������� �ɺ� ���̺�
stack<unordered_map<string, TokenType>> symbolTableStack; // ������ ����
*/

int lineNumber = 1;

string tokenTypeToString(TokenType type) {
    switch (type) {
        case IDENFR: return "IDENFR";
        case INTCON: return "INTCON";
        case STRCON: return "STRCON";
        case CHRCON: return "CHRCON";
        case MAINTK: return "MAINTK";
        case CONSTTK: return "CONSTTK";
        case INTTK: return "INTTK";
        case CHARTK: return "CHARTK";
        case BREAKTK: return "BREAKTK";
        case CONTINUETK: return "CONTINUETK";
        case IFTK: return "IFTK";
        case ELSETK: return "ELSETK";
        case FORTK: return "FORTK";
        case GETINTTK: return "GETINTTK";
        case GETCHARTK: return "GETCHARTK";
        case PRINTFTK: return "PRINTFTK";
        case RETURNTK: return "RETURNTK";
        case VOIDTK: return "VOIDTK";
        case NOT: return "NOT";
        case AND: return "AND";
        case OR: return "OR";
        case MULT: return "MULT";
        case DIV: return "DIV";
        case MOD: return "MOD";
        case LSS: return "LSS";
        case LEQ: return "LEQ";
        case GRE: return "GRE";
        case GEQ: return "GEQ";
        case EQL: return "EQL";
        case NEQ: return "NEQ";
        case ASSIGN: return "ASSIGN";
        case PLUS: return "PLUS";
        case MINU: return "MINU";
        case SEMICN: return "SEMICN";
        case COMMA: return "COMMA";
        case LPARENT: return "LPARENT";
        case RPARENT: return "RPARENT";
        case LBRACK: return "LBRACK";
        case RBRACK: return "RBRACK";
        case LBRACE: return "LBRACE";
        case RBRACE: return "RBRACE";
        default: return "UNKNOWN";
    }
}

/*
void enterScope(){
    symbolTableStack.push(currentScopeSymbols);
    currentScopeSymbols.clear();
}

void exitScope(){
    if(!symbolTableStack.empty())
    {
        currentScopeSymbols = symbolTableStack.top();
        symbolTableStack.pop();
    }
}
*/

int main() 
{
    ifstream inputFile("testfile.txt"); 
    char currentChar;

    while (inputFile.get(currentChar)) 
    {
        if (isspace(currentChar)) 
        {
            if (currentChar == '\n') 
            {
                lineNumber++;
            }
            continue; 
        }

        // �ּ� ó�� �� ������ ó��
        else if(currentChar == '/')
        {
            char nextChar = inputFile.peek();

            // �ּ��ε� /*�� ������ ���
            if(nextChar == '*')
            {
                inputFile.get(); // '*' �Һ�
                bool endofComment = false;

                while(inputFile.get(currentChar))
                {
                    if(currentChar == '\n')
                    {
                        lineNumber++;
                    }

                    else if(currentChar == '*')
                    {
                        if(inputFile.peek() == '/')
                        {
                            inputFile.get(); // '/' �Һ�
                            endofComment = true;
                            break;
                        }
                    }

                    if (inputFile.eof()) break; // ���� ���� ���� �� ����
                }
                
                continue;
            }

            // �ּ��ε� //�� ������ ���
            else if(nextChar == '/')
            {
                inputFile.get(); // �� ��° '/' �Һ�
                while(inputFile.get(currentChar))
                {
                    if(currentChar == '\n' || currentChar == '\r')
                    {
                        lineNumber++; // �� ��ȣ ����
                        break;
                    }
                    if (inputFile.eof()) break; // ���� ���� ���� �� ����
                }

                continue;
            }

            // �������� ���
            else
            {
                tokens.push_back({DIV, "/", lineNumber});
            }
        }

        // �ĺ��� ó��
        else if (isalpha(currentChar) || currentChar == '_') 
        {
            string ident;   // �ĺ��� ���� 
            ident += currentChar;

            while (inputFile.peek() != EOF && (isalnum(inputFile.peek()) || inputFile.peek() == '_')) 
            {
                ident += inputFile.get();
            }

            // Ű�������� �Ǵ�
            if (keywords.find(ident) != keywords.end()) 
            {
                tokens.push_back({keywords[ident], ident, lineNumber});
            }
            else 
            {
                // �ĺ��� ��ū �߰�
                tokens.push_back({IDENFR, ident, lineNumber});
            }
        }


        // ���� ó��
        else if (isdigit(currentChar)) 
        {
            string number;
            number += currentChar;

            // EOF üũ �߰�
            while (isdigit(inputFile.peek())) 
            {
                number += inputFile.get();
            }
            tokens.push_back({INTCON, number, lineNumber});
        }

        // ���ڿ� ��� ó��
        else if (currentChar == '"') 
        {
            string strConst;
            strConst += currentChar;
            bool closed = false;

            while (inputFile.peek() != EOF) 
            {
                char c = inputFile.get();
                strConst += c;

                if (c == '"') 
                {
                    closed = true;
                    break;
                }

                if (c == '\n') 
                {
                    lineNumber++;
                    break;
                }

                if (inputFile.eof()) break; // ���� ���� ���� �� ����
            }

            if (closed) 
            {
                tokens.push_back({STRCON, strConst, lineNumber});
            }
        }

        // ���� ��� ó��
        else if (currentChar == '\'') 
        {
            string charConst;
            charConst += currentChar;       // ù ��° ����ǥ �߰�
            char c = inputFile.get();
            charConst += c;

            if (c == '\\') // �̽������� ������ ����
            {
                char nextChar = inputFile.get();
                charConst += nextChar; // �̽������� �������� �� ��° ���� �߰�
                c = nextChar; // c�� ������Ʈ�Ͽ� ���� �˻翡�� ���
            }

            if (inputFile.peek() == '\'') 
            {
                charConst += inputFile.get(); // ���� ����ǥ �߰�
                tokens.push_back({CHRCON, charConst, lineNumber});
            } 

            else
            {
                // ���� �߻� �� errors ���Ϳ� �߰�
                errors.push_back({lineNumber, 'a'}); // ���� �ڵ� ����
            }
        }
        
        // ������ �� ������ ó��
        else 
        {
            string op(1, currentChar);
            char nextChar = inputFile.peek();

            if (currentChar == '&') 
            {
                if(nextChar == '&')
                {
                    op += inputFile.get();
                    tokens.push_back({AND, op, lineNumber});
                }
                else
                {
                    errors.push_back({lineNumber, 'a'}); // ���� '&' ����
                }
            }

            else if (currentChar == '|') 
            {
                if(nextChar == '|')
                {
                    op += inputFile.get();
                    tokens.push_back({OR, op, lineNumber});
                }
                else
                {
                    errors.push_back({lineNumber, 'a'}); // ���� '|' ����
                }
            }

            else if ((currentChar == '!' || currentChar == '=' || currentChar == '<' || currentChar == '>') && nextChar == '=') 
            {
                op += inputFile.get();
                tokens.push_back({operators[op], op, lineNumber});
            }

            else if (operators.find(op) != operators.end()) 
            {
                tokens.push_back({operators[op], op, lineNumber});
            }
        }

        if (inputFile.eof()) break; // ���� ���� ���� �� ����
    }

    inputFile.close();

    // ���� �߻� ���ο� ���� ��� ���� ����
    if (errors.empty())
    {
        ofstream outputFile("lexer.txt");
        for (const auto& token : tokens) 
        {
            outputFile << tokenTypeToString(token.type) << " " << token.value << endl;
        }
        outputFile.close();
    }
    else 
    {
        ofstream errorFile("error.txt");
        for (const auto& error : errors)
        {
            errorFile << error.lineNumber << " " << error.errorcode << endl;
        }
        errorFile.close();
    }

    return 0;
}

